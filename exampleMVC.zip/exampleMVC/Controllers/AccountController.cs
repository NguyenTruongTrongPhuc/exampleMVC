using Microsoft.AspNetCore.Mvc;
using exampleMVC.Models;
using System.Collections.Generic;
using System.Linq;

namespace exampleMVC.Controllers
{
    public class AccountController : Controller
    {
        private static List<NewUserModel> users = new List<NewUserModel>();
        private static int nextUserId = 1;

        // GET: Account/Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: Account/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(NewUserModel user)
        {
            if (ModelState.IsValid)
            {
                user.UserID = nextUserId++;
                users.Add(user);
                return RedirectToAction("Login");
            }
            return View(user);
        }

        // GET: Account/Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginUserModel model)
        {
            if (ModelState.IsValid)
            {
                var user = users.FirstOrDefault(u => u.Username == model.Username && u.Password == model.Password);
                if (user != null)
                {
                    HttpContext.Session.SetInt32("UserID", user.UserID);
                    HttpContext.Session.SetString("Username", user.Username); // Lưu tên người dùng vào session
                    TempData["Message"] = "Đăng nhập thành công!";
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Tên đăng nhập hoặc mật khẩu không đúng.");
                }
            }
            return View(model);
        }

        // GET: Account/Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("UserID");
            HttpContext.Session.Remove("Username"); // Xóa tên người dùng khỏi session
            return RedirectToAction("Login");
        }
    }
}
