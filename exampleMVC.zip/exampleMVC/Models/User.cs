using System.ComponentModel.DataAnnotations;

namespace exampleMVC.Models
{
    public class User
    {
        private static int nextId = 1;

        public User() {
            UserID = nextId++;
        }
        public int UserID { get; set; }

        public string Name { get; set; }

        public int Age { get; set; }

        public string Role { get; set; }
    }
}
