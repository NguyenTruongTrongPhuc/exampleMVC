using Microsoft.AspNetCore.Mvc;
using exampleMVC.Models;
using System.Linq;
using System.Collections.Generic;

namespace exampleMVC.Controllers
{
    
    public class UserController : Controller
    {
        private static List<User> users = new List<User>();

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Use for assign ID (the most recently people who was added to list will have ID of the people recently who was deleted from stack //
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private static Queue<int> deletedIds = new Queue<int>();
        private static int nextId = 1;

        // GET: User
        public IActionResult Index()
        {
            return View(users);
        }

        // GET: User/Details/5
        public IActionResult Details(int id)
        {
            var user = users.FirstOrDefault(u => u.UserID == id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        // GET: User/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: User/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("UserID,Name,Age,Role")] User user)
        {
            if (ModelState.IsValid)
            {
                // Assign ID
                if (deletedIds.Any())
                {
                    user.UserID = deletedIds.Dequeue();
                }
                else
                {
                    user.UserID = nextId++;
                }
                users.Add(user);
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        // GET: User/Edit/5
        public IActionResult Edit(int id)
        {
            var user = users.FirstOrDefault(u => u.UserID == id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        // POST: User/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("UserID,Name,Age,Role")] User user)
        {
            if (id != user.UserID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var existingUser = users.FirstOrDefault(u => u.UserID == id);
                if (existingUser != null)
                {
                    existingUser.Name = user.Name;
                    existingUser.Age = user.Age;
                    existingUser.Role = user.Role;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        // GET: User/Delete/5
        public IActionResult Delete(int id)
        {
            var user = users.FirstOrDefault(u => u.UserID == id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        // POST: User/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var user = users.FirstOrDefault(u => u.UserID == id);
            if (user != null)
            {
                users.Remove(user);
                deletedIds.Enqueue(user.UserID);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
