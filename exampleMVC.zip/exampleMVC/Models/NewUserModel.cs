namespace exampleMVC.Models
{
    public class NewUserModel
    {
        public int UserID { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
