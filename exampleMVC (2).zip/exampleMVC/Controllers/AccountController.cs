using Microsoft.AspNetCore.Mvc;
using exampleMVC.Models;

namespace exampleMVC.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account/Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                // Xác thực người dùng (giả sử Username: admin, Password: password)
                if (model.Username == "admin" && model.Password == "password")
                {
                    // Đăng nhập thành công
                    TempData["Message"] = "Đăng nhập thành công!";
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    // Đăng nhập thất bại
                    ModelState.AddModelError(string.Empty, "Tên đăng nhập hoặc mật khẩu không đúng.");
                }
            }
            return View(model);
        }
    }
}
