namespace exampleMVC.Models
{
    public class LoginUserModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
